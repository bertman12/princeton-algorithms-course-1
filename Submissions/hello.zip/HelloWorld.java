// import edu.princeton.cs.algs4.StdIn;
// import edu.princeton.cs.algs4.StdOut;
// import edu.princeton.cs.algs4.StdRandom;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}

