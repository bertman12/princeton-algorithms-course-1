// import edu.princeton.cs.algs4.StdIn;
// import edu.princeton.cs.algs4.StdOut;
// import edu.princeton.cs.algs4.StdRandom;

public class HelloGoodbye {
    
    public static void main(String[] args) {
        String personOne = args[0];
        String personTwo = args[1];
        var text = "Hello "+personOne + " and "+personTwo+".";
        System.out.println(text);
        text = "Goodbye "+personOne + " and "+personTwo+".";
        System.out.println(text);
    }
}
